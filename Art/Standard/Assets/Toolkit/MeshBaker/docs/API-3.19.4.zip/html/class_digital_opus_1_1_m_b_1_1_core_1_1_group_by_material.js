var class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_material =
[
    [ "Compare", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_material.html#af4cf07e382dfce140ede4e44aaab0c0f", null ],
    [ "GetDescription", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_material.html#ae888c0ce3e857632b818add3468f7511", null ],
    [ "GetName", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_material.html#a3a2bba79349e634919027ad87b0ee819", null ]
];