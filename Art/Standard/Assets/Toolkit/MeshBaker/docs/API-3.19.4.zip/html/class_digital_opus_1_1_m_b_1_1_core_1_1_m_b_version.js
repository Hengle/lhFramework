var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version =
[
    [ "FindSceneObjectsOfType", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#a7358e07141f586ecc6487bd27d3579bc", null ],
    [ "GetActive", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#aeba3e0bd8290e51a65550fee7ff07e14", null ],
    [ "GetBones", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#a0287cfabd6bf003d2569ce9ae188650f", null ],
    [ "GetLightmapTilingOffset", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#a781141cdc5aedff5202cb24b1824058f", null ],
    [ "GetMajorVersion", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#a4e669242c77a4a4293b56249c0cfe974", null ],
    [ "GetMeshUV3orUV4", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#af6de669ba944150605c8f3041b750cce", null ],
    [ "GetMinorVersion", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#a87ab632eedc64496356b18456418774c", null ],
    [ "IsRunningAndMeshNotReadWriteable", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#a808846e34ebe1a1a00293b7e968e06cd", null ],
    [ "MeshAssignUV3", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#ae288892839561a19d11fb33f017851d4", null ],
    [ "MeshAssignUV4", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#ab0813310fbe3c029d30fb714298104e7", null ],
    [ "MeshClear", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#ae9a6b6b881bd0ae908b6a04902b100e5", null ],
    [ "SetActive", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#a016ac3ea5691b1cce6be2208c55a42e0", null ],
    [ "SetActiveRecursively", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#aaf8503aa85b52ce7278c42d29176a51f", null ],
    [ "version", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html#a246e9fa45a8ed6070dfcf1c85b78d97e", null ]
];