var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___copy_bone_weights =
[
    [ "CopyBoneWeightsFromSeamMeshToOtherMeshes", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___copy_bone_weights.html#a1d31b0fbdd11e082b61e71e7f13327ec", null ]
];