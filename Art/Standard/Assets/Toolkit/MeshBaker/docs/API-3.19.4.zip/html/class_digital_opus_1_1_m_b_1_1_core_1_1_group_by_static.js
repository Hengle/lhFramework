var class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_static =
[
    [ "Compare", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_static.html#a1f9b811e55d8b8dac96ac64a314ac346", null ],
    [ "GetDescription", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_static.html#a5c730e455af3c66007cb9f5b0c927be8", null ],
    [ "GetName", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_static.html#a62dc5a925516870e8f9b382b07b23d58", null ]
];